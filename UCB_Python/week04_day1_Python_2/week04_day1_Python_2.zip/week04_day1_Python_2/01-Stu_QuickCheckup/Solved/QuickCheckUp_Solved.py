# Print Hello User!
print("Hello User!")

# Take in User Input
name = input("What is your name? ")

# Respond Back with User Input
print("Hi " + name + "!")

# Take in the User Age
age = input("What is your age? ")

# Respond Back with a statement based on age
if (int(age) < 8):
    print("Aww! You are just a baby!")

if (int(age) >= 8):
    print("Ah... A well traveled soul are ye!") 